package stepDefinition;

import java.util.List;

import org.openqa.selenium.support.PageFactory;

import com.automation.Utilities.Utilities;
import com.automation.pages.LoginPage;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class LoginDef extends Utilities {
	LoginPage login;

	@Given("^Open the browser and start application$")
	public void open_the_browser_and_start_application() throws Throwable {
		driver = initializeDriver();
		login = PageFactory.initElements(driver, LoginPage.class);
	}

	@When("^I enter username and password$")
	public void i_enter_username_and_password(DataTable dt) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		// For automatic transformation, change DataTable to one of
		// List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		// E,K,V must be a scalar (String, Integer, Date, enum etc)

		List<String> list = dt.asList(String.class);
		login.enterLoginDetails(list.get(0).toString(), list.get(1).toString());

	}

	@When("^click on login$")
	public void click_on_login() {
		login.clickLoginButton();

	}

	@When("^I enter the credentials and login$")
	public void i_enter_the_credential_and_login(DataTable dt) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		// For automatic transformation, change DataTable to one of
		// List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		// E,K,V must be a scalar (String, Integer, Date, enum etc)

		List<String> list = dt.asList(String.class);
		login.enterLoginDetails(list.get(0).toString(), list.get(1).toString());
		login.clickLoginButton();

	}

	@And("^i close the browser$")
	public void i_close_the_browser() {
		login.closeTheBrowser();

	}
}
