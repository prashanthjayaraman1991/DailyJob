package stepDefinition;

import org.openqa.selenium.support.PageFactory;

import com.automation.Utilities.Utilities;
import com.automation.pages.UserLandingPage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserLandingDef extends Utilities {
	UserLandingPage userLandingPage;

	@When("^I enter \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" Travellers and Class$")
	public void i_enter_Travellers_and_Class(String fromCity, String toCity, String date, String month,
			String noOfPassengers) throws Throwable {
		userLandingPage = PageFactory.initElements(driver, UserLandingPage.class);
		userLandingPage.enterSearchingDetails(fromCity, toCity, date, month, noOfPassengers);
	}

	@When("^click on search$")
	public void click_on_search() {
		userLandingPage.clickOnSearch();
	}

	@Then("^List of flights should be displayed$")
	public void list_of_flights_should_be_displayed() {

	}

}
