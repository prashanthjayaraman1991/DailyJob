package com.automation.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.automation.Utilities.Utilities;

public class UserLandingPage extends Utilities {
	WebDriver driver;

	@FindBy(xpath = "//*[@class='fsw_inputBox searchCity inactiveWidget ']")
	WebElement fromCityLabel;

	@FindBy(xpath = "//*[@id='fromCity']")
	WebElement fromCity;

	@FindBy(xpath = "//*[@class='fsw_inputBox searchToCity inactiveWidget ']")
	WebElement toCityLabel;

	@FindBy(xpath = "//*[@id='toCity']")
	WebElement toCity;

	@FindBy(xpath = "//div[contains(@class,'fsw_inputBox dates inactiveWidget')]//label")
	WebElement depatureDate;

	@FindBy(xpath = "//*[@class='primaryBtn btnApply pushRight ' and contains(text(),'APPLY')]")
	WebElement applyButton;

	@FindBy(xpath = "//*[@class='primaryBtn font24 latoBold widgetSearchBtn ' and contains(text(),'Search')]")
	WebElement searchButton;

	@FindBy(xpath = "//*[@class='fsw_inputBox dates inactiveWidget ']")
	WebElement departureButton;

	@FindBy(css = ".DayPicker-Caption")
	WebElement dateCaption;

	public UserLandingPage(WebDriver driver) {
		this.driver = driver;
		this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public void enterSearchingDetails(String cityFrom, String cityTo, String date, String month,
			String noOfPassengers) {
		waitFor("3");

		fromCityLabel.click();
		fromCity.sendKeys(cityFrom);
		getCityList(cityFrom, driver);
		// Get to City
		toCityLabel.click();
		toCity.sendKeys(cityTo);
		getCityList(cityTo, driver);
		// Get Depature date

		handleDate(date, month, driver);
		gettravellersAndClass();
		selectTravellersAndClass(noOfPassengers, driver);

	}

	public void getCityList(String city, WebDriver driver) {
		waitFor("1");

		List<WebElement> options = driver
				.findElements(By.xpath("//ul[@class = 'react-autosuggest__suggestions-list']/li/div/div/p"));
		for (WebElement option : options) {
			if (option.getText().startsWith(city)) {
				JavascriptExecutor exe = (JavascriptExecutor) driver;
				exe.executeScript("arguments[0].click();", option);
				break;
			}

		}
	}

	public void handleDate(String date, String month, WebDriver driver) {
		waitFor("1");

		departureButton.click();
		WebElement dateCaption = driver.findElement(By.cssSelector(".DayPicker-Caption"));
		while (!dateCaption.getText().contains(month)) {
			driver.findElement(By.xpath("//span[@class='DayPicker-NavButton DayPicker-NavButton--next']")).click();
		}

		List<WebElement> dates = driver.findElements(By.cssSelector(".DayPicker-Day"));
		for (WebElement date1 : dates) {
			if (date1.getText().startsWith(date)) {

				date1.click();
				break;
			}
		}
	}

	public void gettravellersAndClass() {
		WebElement option = driver.findElement(
				By.cssSelector("div[data-cy='flightTraveller'] [class='lbl_input latoBold appendBottom10']"));
		JavascriptExecutor exe = (JavascriptExecutor) driver;
		exe.executeScript("arguments[0].click();", option);

	}

	public void selectTravellersAndClass(String adults, WebDriver driver) {
		driver.findElement(By.xpath("//div[@class='travellers']/div[@class='appendBottom20']/ul[1]/li[" + adults + "]"))
				.click();
		applyButton.click();

	}

	public void clickOnSearch() {
		searchButton.click();
		waitFor("10");
	}
}
